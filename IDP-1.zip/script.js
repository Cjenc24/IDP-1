let shapecolor1='yellow'
let shapecolor2='green'
let shapecolor3='midnightblue'
let shapecolor4='black'
let shapecolor5='white'
let shapecolor6='orange'
let shapecolor7='purple'
let help = {
  text: [
    "Press '2' to move drawings up",
    "Press '1' to move drawings down",
    "Press 'c' to change colors",
    "Press 'r' to go back to original colors",
"Press 's' to move the shape faster",
    "press ^ to hide/show instructions*",
  ],
  size: 15,
  visible: true,
};
function drawIns() {
  if (help.visible) {
    textSize(help.size);
    let i = 15;
    for (let line of help.text) {
      text(line, 15, i);
      i += 15;
    }
  }
}
function setup() {
  createCanvas(windowWidth, windowHeight);
    background('dodgerblue');
     x = 1;
     changeDirection=false;
  y=0;
  
}

function draw() {
  background('dodgerblue');
  //instructions have to be below background so not overlapped
    fill('black');
  drawIns();
  myShape(x,y,300,250)
  myShape2(x,y,500,400)
  //noStroke()
  
if(x>width){
  // if x is greater than width of screen--> change direction
		changeDirection=true}
    else if (x<=0){
		changeDirection=false}

	if (x>=0 && changeDirection == false){
		x=x+3}
    else if(changeDirection == true){
		x=x-1}
}
 

function myShape(x,y,w,h){
  //blue/yellow fish
  //each part is scale to the screen
fill(shapecolor1);
arc(x+w*4/8,y+h*3/6,w*3/8,h*3.5/6,PI,TWO_PI)
triangle(x+w*.5/8,y+h*2/6,x+w*.5/8,y+h*4/6,x+w*3/8,y+h*3/6)
fill(shapecolor2);
line(x+w*4/8,y+h*2.9/6,x+w*1.75/8,y+h*2.9/6)
line(x+w*4/8,y+h*3.1/6,x+w*1.75/8,y+h*3.1/6)
line(x+w*4/8,y+h*3.35/6,x+w*1.5/8,y+h*2.5/6)
line(x+w*4/8,y+h*2.85/6,x+w*1.5/8,y+h*3.4/6)
fill(shapecolor3);
ellipse(x+w*4/8,y+h*3/6,w*3.8/8,h*2.3/6)
fill(shapecolor1);
triangle(x+w*3.9/8,y+h*3/6,x+w*2.75/8,y+h*3.7/6,x+w*4.25/8,y+h*3.7/6)
fill(shapecolor4);
circle(x+w*5/8,y+h*2.7/6,w*.75/8)
fill(shapecolor2);
line(x+w*3.7/8,y+h*3.25/6,x+w*4.05/8,y+h*3.7/6)
line(x+w*3.5/8,y+h*3.4/6,x+w*3.85/8,y+h*3.7/6)
line(x+w*4/8,y+h*1.25/6,x+w*4/8,y+h*1.6/6)
line(x+w*3.7/8,y+h*1.3/6,x+w*3.7/8,y+h*1.55/6)
line(x+w*4.3/8,y+h*1.3/6,x+w*4.3/8,y+h*1.55/6)
line(x+w*3.5/8,y+h*1.35/6,x+w*3.5/8,y+h*1.5/6)
fill(shapecolor5)
circle(x+w*5.2/8,y+h*2.8/6,w*.3/8)
}
function myShape2(a,b,c,d){
//purple fish
//each part scale to the screen, opposite direction as blue fish
fill(shapecolor6);
triangle(a+c*4/8,b+d*4/7,a+c*5.5/8,b+d*3.5/7,a+c*5.5/8,b+d*4.5/7)
fill(shapecolor7);
triangle(a+c*3/8,b+d*4/7,a+c*5/8,b+d*3/7,a+c*5/8,b+d*5/7)
fill(shapecolor6);
arc(a+c*4.25/8, b+d*4.2/7,c*.5/8,d*.5/7,TWO_PI,PI)
fill(shapecolor4);
circle(a+c*3.6/8,b+d*3.9/7,c*.25/8)
line(a+c*5.25/8,b+d*3.8/7,a+c*5.5/8,b+d*3.8/7)
line(a+c*5.25/8,b+d*4.2/7,a+c*5.5/8,b+d*4.2/7)
fill(shapecolor5);
circle(a+c*3.55/8,b+d*3.95/7,c*.1/8)
}
function keyPressed(){
  //moving down
  if(key === '1'){
    y=y+10
  }
  //moving up
  if(key === '2'){
    y=y-10
  }
  //changing colors
  if(key ==='c'){
    shapecolor1='coral'
    shapecolor3='darkolivegreen'
    shapecolor6='deeppink'
    shapecolor7='gold'
  }
  //reverting colors
  if (key === 'r'){
    shapecolor1='yellow'
    shapecolor3='midnightblue'
    shapecolor6='orange'
    shapecolor7='purple'
  }
  //increasing speed by adding x
  if (key === 's'){
     if (x>=-5 && changeDirection == false){
       x=x+5}
     else if(changeDirection == true){
		   x=x-5}
  }
//gets rid of instructions as prompted
if( key === '^') {
    help.visible = !help.visible;
}
  }